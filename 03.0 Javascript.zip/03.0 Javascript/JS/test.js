/**
 * Created by web on 12/14/2016.
 */
function sample () {
    alert('Hello from Sample.js')
}